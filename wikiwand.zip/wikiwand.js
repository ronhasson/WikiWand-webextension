

var host = window.location.host;
var pathname = window.location.pathname;

var lang = host.substring(0,host.indexOf('.'));
var arti = pathname.split('/')[2];



console.info("wikiwand webextension");
console.group();
console.log(host);
console.log(pathname);

console.log();

console.log(lang);
console.log(arti);
//console.log(window.location.pathname);
console.groupEnd();

window.location.href = "https://wikiwand.com/"+ lang +"/" + arti;
